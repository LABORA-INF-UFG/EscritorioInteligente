from flask import Flask, Blueprint, request
import yaml, time, json
import paho.mqtt.client as mqtt

api_alert = Blueprint('api_alert', 'api_alert', url_prefix='/api_alert')
broker_host = 'localhost'
broker_port = 1883
topic = 'raspberry'
@api_alert.route('monitoring', methods=['POST'])
def monitoring_api():
    client = mqtt.Client()
    client.connect(host=broker_host, port=broker_port)
    client.loop_start()
        
    msg_request = yaml.load(request.data)
    try:
        response = client.publish(topic, json.dumps(msg_request))
        response.wait_for_publish()
        if not response.is_published():
            print(response)
    except:
        pass

    client.loop_stop()
    return "ok", 201